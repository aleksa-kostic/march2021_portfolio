// Graphs - vertex.h
// Aleksa Kostic
// 24 March 2021

#ifndef VERTEX_H
#define VERTEX_H

template <typename Elem>
class Edge;
#include "edge.hpp"

template <typename Elem>
class Vertex 
{
private:
	Elem u;
	size_t incidentListSize;
	size_t incidentListCapacity;
	Edge<Elem>* incidentList;

public:
	Vertex(Elem element)
		: u{ element }, incidentListSize{ 0 }, incidentListCapacity{ 5 }, incidentList{ new Edge<Elem>[5] }
	{};
	~Vertex();

	Elem& operator*();
	Edge<Elem>* incidentEdges();
	bool isAdjacentTo(Vertex<Elem>& v);
	void addIncident(Edge<Elem>& i);
};

#endif // VERTEX_H
