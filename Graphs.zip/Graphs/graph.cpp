// Graphs - graph.cpp
// Aleksa Kostic
// 24 March 2021

#include "edge.hpp"
#include "graph.hpp"
#include "vertex.hpp"

template <typename Elem>
Graph<Elem>::~Graph()
{
	delete[] vertexList;
	delete[] edgeList;
}

template <typename Elem>
Vertex<Elem>* Graph<Elem>::verticies()
{
	return vertexList;
}

template <typename Elem>
Edge<Elem>* Graph<Elem>::edges()
{
	return edgeList;
}

template <typename Elem>
void Graph<Elem>::insertVertex(Vertex<Elem> x)
{
	if (vertexListSize == vertexListCapacity)
	{
		Vertex<Elem>* temp = new Vertex<Elem>[vertexListCapacity + 5];
		for (unsigned i = 0; i < vertexListCapacity; i++)
		{
			temp[i] = vertexList[i];
		}

		delete[] vertexList;
		vertexList = temp;
	}
	vertexList[vertexListSize] = x;
	vertexListSize++;
	vertexListCapacity += 5;
}

template <typename Elem>
void Graph<Elem>::insertEdge(Vertex<Elem> v, Vertex<Elem> w, Elem x)
{
	if (edgeListSize == edgeListCapacity)
	{
		Edge<Elem>* temp = new Edge<Elem>[edgeListCapacity + 5];
		for (unsigned i = 0; i < edgeListCapacity; i++)
		{
			temp[i] = edgeList[i];
		}

		delete[] edgeList;
		edgeList = temp;
	}
	edgeList[edgeListSize] = x;
	edgeListSize++;
	edgeListCapacity += 5;
}

template <typename Elem>
void Graph<Elem>::eraseVertex(Vertex<Elem> v)
{
	for (Vertex<Elem> e : vertexList)
	{
		if (*e == *v) {
			e.~Vertex;
		}
	}
}

template <typename Elem>
void Graph<Elem>::eraseEdge(Edge<Elem> e)
{
	for (Edge<Elem> er : edgeList)
	{
		er.~Edge;
	}
}
