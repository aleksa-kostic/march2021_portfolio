// Graphs - vertex.cpp
// Aleksa Kostic
// 24 March 2021

#include "edge.hpp"
#include "vertex.hpp"

template<typename Elem>
Vertex<Elem>::~Vertex()
{
	for (Edge<Elem> e : incidentList)
	{
		e.~Edge();
	}
	delete[] incidentList;
}

template <typename Elem>
Elem& Vertex<Elem>::operator*()
{
	return u;
}

template<typename Elem>
Edge<Elem>* Vertex<Elem>::incidentEdges()
{
	return incidentList;
}

template <typename Elem>
bool Vertex<Elem>::isAdjacentTo(Vertex<Elem>& v)
{
	Edge<Elem> argumentEdge = Edge<Elem>(u, v);
	for (Edge<Elem> e : incidentList)
	{
		Vertex<Elem>* temp = e.endVertices(); // temp: [e.start, e.end]
		Vertex<Elem>* argEdgVert = argumentEdge.endVertices();

		// if (argument.u == e.u) AND (argument.v == e.v)
		if (**argEdgVert == **temp && **(argEdgVert + 1) == **(temp + 1))
		{
			return true;
		}
		// else if (e.v == argument.u) AND (e.u == argument.v)
		else if (**(temp + 1) == **argEdgVert && **temp == **(argEdgVert + 1))
		{
			return true;
		}
	}
	return false;
}

template<typename Elem>
void Vertex<Elem>::addIncident(Edge<Elem>& i)
{
	// RESIZE if size == capacity
	if (incidentListSize == incidentListCapacity) {
		Edge<Elem>* temp = new Edge<Elem>[incidentListCapacity + 5];
		for (int n = 0; n < incidentListCapacity; n++) {
			temp[n] = incidentList[n];
		}
		delete[] incidentList;
		incidentList = temp;
	}
	
	// copy incident i into incidentList
	incidentList[incidentListSize] = i;
	incidentListSize++;
	incidentListCapacity += 5;
}
