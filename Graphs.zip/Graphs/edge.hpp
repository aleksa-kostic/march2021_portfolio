// Graphs - edge.h
// Aleksa Kostic
// 24 March 2021

#ifndef EDGE_H
#define EDGE_H

template<typename Elem>
class Vertex;

#include "vertex.hpp"

template <typename Elem>
class Edge
{
private:
	Vertex<Elem> v;
	Vertex<Elem> w;
	Elem x;
	Vertex<Elem>* pair;
public:
	Edge(Vertex<Elem> start, Vertex<Elem> end, Elem element)
		: v{ start }, w{ end }, x{ element }, pair{ new Vertex[2] }
	{
		pair[0] = v;
		pair[1] = w;
	};
	Edge(Vertex<Elem> start, Vertex<Elem> end)
		: v{ start }, w{ end }, pair{ new Vertex[2] }
	{
		pair[0] = v;
		pair[1] = w;
	};
	~Edge();

	Elem& operator*();
	Vertex<Elem>* endVertices();
	bool isAdjacentTo(Edge<Elem>& f);
	bool isIncidentOn(Vertex<Elem>& s);
};

#endif // EDGE_H
