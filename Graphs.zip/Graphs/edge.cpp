// Graphs - edge.cpp
// Aleksa Kostic
// 24 March 2021

#include "edge.hpp"
#include "vertex.hpp"

template <typename Elem>
Edge<Elem>::~Edge()
{
	delete[] pair;
}

template <typename Elem>
Elem& Edge<Elem>::operator*()
{
	return x;
}

template <typename Elem>
Vertex<Elem>* Edge<Elem>::endVertices()
{
	return pair;
}

template <typename Elem>
bool Edge<Elem>::isAdjacentTo(Edge<Elem>& f)
{
	Vertex<Elem>* fEnd = f.endVertices();
	if (**f == **pair ||
		**f == **(pair + 1) ||
		**(f + 1) == **pair ||
		**(f + 1) == **(pair + 1)) {
		return true;
	}
	else {
		return false;
	}
}

template <typename Elem>
bool Edge<Elem>::isIncidentOn(Vertex<Elem>& s)
{
	if (**pair == *s || **(pair + 1) == *s)
	{
		return true;
	}
	else 
	{
		return false;
	}
}