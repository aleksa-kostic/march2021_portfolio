// Graphs - graph.h
// Aleksa Kostic
// 24 March 2021

#ifndef GRAPH_H
#define GRAPH_H

#include "edge.hpp"
#include "vertex.hpp"

template <typename Elem>
class Graph
{
private:
	size_t vertexListSize;
	size_t edgeListSize;
	size_t vertexListCapacity;
	size_t edgeListCapacity;
	Vertex<Elem>* vertexList;
	Edge<Elem>* edgeList;

public:
	Graph()
		: vertexListSize{ 0 }, 
		edgeListSize{ 0 },
		vertexListCapacity{ 5 },
		edgeListCapacity{ 5 },
		vertexList{ new Vertex[5] }, 
		edgeList{ new Edge[5] }
	{};
	~Graph();

	Vertex<Elem>* verticies();
	Edge<Elem>* edges();
	void insertVertex(Vertex<Elem> x);
	void insertEdge(Vertex<Elem> v, Vertex<Elem> w, Elem x);
	void eraseVertex(Vertex<Elem> v);
	void eraseEdge(Edge<Elem> e);
};


#endif // GRAPH_H
